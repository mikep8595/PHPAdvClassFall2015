<?php

/**
 * Description of ErrorMessage
 *
 * @author Mpetrarca
 */
class ErrorMessage extends Message{
    
}
