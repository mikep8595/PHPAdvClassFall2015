<?php
if ( true ) {
    die('Please Log in');
}