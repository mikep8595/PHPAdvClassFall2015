<!-- containts HTML used for displaying success messages -->
<?php if ( isset($message) ) : ?>
<p class="bg-success"><?php echo $message; ?></p>
<?php endif; ?>
